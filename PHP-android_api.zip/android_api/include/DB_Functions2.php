<?php
class DB_Functions2 {

    private $conn;

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {

    }

    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($user_id, $Product, $Shop) {


        $stmt = $this->conn->prepare("INSERT INTO Cart(user_id, Product, Shop) VALUES(?, ?, ?)");
        $stmt->bind_param("sss", $user_id, $Product, $Shop);
        $result = $stmt->execute();
        $stmt->close();
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM Cart WHERE Product = ?");
            $stmt->bind_param("s", $Product);
            $stmt->execute();
            $Cart = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $Cart;
        } else {
            return false;
        }
    }


}

?>
