<?php

$host = 'localhost';
$user = 'root';
$pwd = '';
$db = 'android_api';

$conn = mysqli_connect($host, $user, $pwd, $db);
if(!$conn) {
  die("Error in connection: " . $mysqli_connect_error());
}


global $conn;
$user_id = $_POST['user_id'];
$Product = $_POST['Product'];
$Shop = $_POST['Shop'];
$query= " Insert into Cart (user_id,Product,Shop) values ('$user_id','$Product','$Shop');";
mysqli_query($conn, $query) or die (mysqli_error($conn));
mysqli_close($conn);
