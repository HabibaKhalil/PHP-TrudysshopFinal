<?php
$host = 'localhost';
$user = 'root';
$pwd = '';
$db = 'android_api';

$conn = mysqli_connect($host, $user, $pwd, $db);
if(!$conn) {
  die("Error in connection: " . $mysqli_connect_error());
}
global $conn;
$id = $_POST['id'];
$sql_query = "DELETE FROM Cart WHERE id='$id'";
if (mysqli_query($conn, $sql_query)){
echo "Record deleted successfully";
}
else {
echo "Error deleting record: " . mysqli_error($conn);
}

mysqli_close($conn);


?>
